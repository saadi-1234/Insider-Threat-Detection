"""
isolation_forest_model.py
--------------------------
Insider-threat detection over corporate access logs using an Isolation
Forest anomaly detector (scikit-learn).

This is a script version of notebooks/access_log_isolation_forest.ipynb,
organized into functions so it can be imported, tested, or run from the
command line.

Usage:
    python src/isolation_forest_model.py \
        --input data/synthetic_access_logs.csv \
        --output data/flagged_anomalies.csv
"""

import argparse

import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import LabelEncoder

FEATURE_COLUMNS = [
    "user_id",
    "login_location",
    "access_type",
    "resource",
    "device_type",
    "hour",
    "day_of_week",
]

CATEGORICAL_COLUMNS = [
    "user_id",
    "login_location",
    "access_type",
    "resource",
    "device_type",
]


def load_data(path: str) -> pd.DataFrame:
    """Load the raw access log CSV."""
    df = pd.read_csv(path)
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df


def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    """Derive time-based fields and human-readable risk flags."""
    df = df.copy()
    df["hour"] = df["timestamp"].dt.hour
    df["day_of_week"] = df["timestamp"].dt.dayofweek

    df["late_night"] = df["hour"].apply(lambda h: h < 6 or h > 22)
    df["unknown_device"] = df["device_type"].str.lower().str.contains(
        "unknown|unregistered"
    )
    df["sensitive_resource"] = df["resource"].str.lower().str.contains(
        "sensitive|finance"
    )
    df["unusual_location"] = df["login_location"].str.lower().str.contains(
        "unknown"
    )
    return df


def encode_categoricals(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Label-encode categorical columns; keep original values for reporting.

    Returns the encoded dataframe plus a dict of fitted LabelEncoders so
    predictions can be traced back to human-readable values later.
    """
    df = df.copy()
    df["user_id_original"] = df["user_id"]
    df["login_location_original"] = df["login_location"]
    df["resource_original"] = df["resource"]
    df["device_type_original"] = df["device_type"]

    encoders = {}
    for col in CATEGORICAL_COLUMNS:
        encoder = LabelEncoder()
        df[col] = encoder.fit_transform(df[col])
        encoders[col] = encoder
    return df, encoders


def train_model(
    X: pd.DataFrame,
    n_estimators: int = 100,
    contamination: float = 0.01,
    random_state: int = 42,
) -> IsolationForest:
    """Fit an Isolation Forest on the selected feature matrix."""
    model = IsolationForest(
        n_estimators=n_estimators,
        contamination=contamination,
        random_state=random_state,
    )
    model.fit(X)
    return model


def score(df: pd.DataFrame, model: IsolationForest) -> pd.DataFrame:
    """Attach anomaly scores and labels (-1 = anomaly, 1 = normal)."""
    df = df.copy()
    X = df[FEATURE_COLUMNS]
    df["anomaly_score"] = model.decision_function(X)
    df["anomaly"] = model.predict(X)
    return df


def explain(row: pd.Series) -> str:
    """Human-readable justification for why a record was flagged."""
    reasons = []
    if row["late_night"]:
        reasons.append("Late night login")
    if row["unknown_device"]:
        reasons.append("Unknown device")
    if row["sensitive_resource"]:
        reasons.append("Accessed sensitive system")
    if row["unusual_location"]:
        reasons.append("Unusual login location")
    return ", ".join(reasons)


def run_pipeline(input_path: str) -> pd.DataFrame:
    """End-to-end pipeline: load -> engineer -> encode -> train -> score."""
    df = load_data(input_path)
    df = engineer_features(df)
    df, _ = encode_categoricals(df)

    model = train_model(df[FEATURE_COLUMNS])
    df = score(df, model)
    df["explanation"] = df.apply(explain, axis=1)
    return df


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Detect anomalous access-log records with an Isolation Forest."
    )
    parser.add_argument(
        "--input",
        default="data/synthetic_access_logs.csv",
        help="Path to the input access log CSV.",
    )
    parser.add_argument(
        "--output",
        default="data/flagged_anomalies.csv",
        help="Path to write the flagged anomalies CSV.",
    )
    args = parser.parse_args()

    df = run_pipeline(args.input)

    flagged = df[df["anomaly"] == -1][
        [
            "user_id_original",
            "timestamp",
            "login_location_original",
            "resource_original",
            "device_type_original",
            "anomaly_score",
            "explanation",
        ]
    ].rename(
        columns={
            "user_id_original": "user_id",
            "login_location_original": "login_location",
            "resource_original": "resource",
            "device_type_original": "device_type",
        }
    )

    flagged.to_csv(args.output, index=False)
    print(f"Total records scored:   {len(df)}")
    print(f"Anomalies flagged:      {len(flagged)}")
    print(f"Results written to:     {args.output}")


if __name__ == "__main__":
    main()
