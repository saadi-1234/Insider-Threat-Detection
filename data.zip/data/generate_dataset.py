"""
generate_dataset.py
--------------------
Generates the synthetic corporate access-log dataset used to train and
demo the Isolation Forest insider-threat detector in this repository.

The generator produces two classes of records:

1. Normal behaviour (~99% of rows)
   - Business-hours logins (roughly 8am-8pm)
   - Known locations (Bangalore, New York, London, Singapore, Remote-VPN)
   - Known device types (Desktop, Mobile, Laptop)
   - A mix of routine resources (Email, HR Portal, DevOps Dashboard,
     Intranet Wiki, Ticketing System)

2. Injected anomalies (~1% of rows)
   - Late-night logins (00:00-05:00)
   - Unknown/unregistered devices
   - Access to sensitive resources (Finance DB, Sensitive HR Records)
   - Logins from an unrecognized location

Running this script regenerates data/synthetic_access_logs.csv exactly as
consumed by src/isolation_forest_model.py and notebooks/access_log_isolation_forest.ipynb.
"""

import random
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

RANDOM_SEED = 42
NUM_USERS = 50
NUM_NORMAL_RECORDS = 5000
NUM_ANOMALOUS_RECORDS = 50
START_DATE = datetime(2023, 1, 1)
END_DATE = datetime(2023, 1, 31)

NORMAL_LOCATIONS = ["Bangalore", "New York", "London", "Singapore", "Remote-VPN"]
NORMAL_DEVICES = ["Desktop", "Mobile", "Laptop"]
NORMAL_RESOURCES = [
    "Email",
    "HR Portal",
    "DevOps Dashboard",
    "Intranet Wiki",
    "Ticketing System",
]
ACCESS_TYPES = ["read", "write", "upload", "download"]

ANOMALOUS_LOCATION = "Unknown"
ANOMALOUS_DEVICE = "Unknown Device"
SENSITIVE_RESOURCES = ["Finance DB", "Sensitive HR Records"]


def random_timestamp(start: datetime, end: datetime, hour_range=None) -> datetime:
    """Return a random timestamp between start and end (inclusive of date range).
    If hour_range is given (tuple of ints), the hour is constrained to that set."""
    delta_days = (end - start).days
    day_offset = random.randint(0, delta_days)
    base_day = start + timedelta(days=day_offset)
    if hour_range is not None:
        hour = random.choice(hour_range)
    else:
        hour = random.randint(6, 22)  # business-hours-ish
    return base_day.replace(hour=hour, minute=0, second=0, microsecond=0)


def generate_normal_records(n: int) -> list[dict]:
    records = []
    for _ in range(n):
        user_id = f"user_{random.randint(1, NUM_USERS)}"
        timestamp = random_timestamp(START_DATE, END_DATE)
        records.append(
            {
                "user_id": user_id,
                "timestamp": timestamp,
                "login_location": random.choice(NORMAL_LOCATIONS),
                "access_type": random.choice(ACCESS_TYPES),
                "resource": random.choice(NORMAL_RESOURCES),
                "device_type": random.choice(NORMAL_DEVICES),
            }
        )
    return records


def generate_anomalous_records(n: int) -> list[dict]:
    """Insider-threat-style anomalies: late-night + unknown device +
    sensitive resource + (occasionally) an unrecognized location."""
    records = []
    for _ in range(n):
        user_id = f"user_{random.randint(1, NUM_USERS)}"
        timestamp = random_timestamp(START_DATE, END_DATE, hour_range=range(1, 4))
        records.append(
            {
                "user_id": user_id,
                "timestamp": timestamp,
                "login_location": random.choice(
                    NORMAL_LOCATIONS + [ANOMALOUS_LOCATION]
                ),
                "access_type": random.choice(["download", "upload"]),
                "resource": random.choice(SENSITIVE_RESOURCES),
                "device_type": ANOMALOUS_DEVICE,
            }
        )
    return records


def main() -> None:
    random.seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)

    normal = generate_normal_records(NUM_NORMAL_RECORDS)
    anomalous = generate_anomalous_records(NUM_ANOMALOUS_RECORDS)

    df = pd.DataFrame(normal + anomalous)
    df = df.sort_values("timestamp").reset_index(drop=True)

    output_path = "synthetic_access_logs.csv"
    df.to_csv(output_path, index=False)
    print(f"Wrote {len(df)} rows to {output_path}")
    print(f"  Normal records:    {len(normal)}")
    print(f"  Anomalous records: {len(anomalous)}")


if __name__ == "__main__":
    main()
